const test = globalThis.test || require('node:test').test;
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const autoCapturePath = path.join(__dirname, '..', 'auto-capture.js');
const autoCaptureSource = fs.readFileSync(autoCapturePath, 'utf8');
const autoLogic = require('../auto-logic.js');

function makeTextNode(value) {
  return { nodeType: 3, nodeValue: value };
}

function makeElement(tagName, children = [], options = {}) {
  return {
    nodeType: 1,
    tagName,
    children,
    className: options.className || '',
    id: options.id || '',
    innerText: options.innerText || '',
    type: '',
    value: '',
    style: {},
    setAttribute() {},
    appendChild(child) { this.children.push(child); },
    remove() {},
    contains(node) {
      if (this === node) return true;
      return this.children.some(child => child === node || (child.contains && child.contains(node)));
    },
    querySelector() { return null; },
  };
}

function makeHarness(options = {}) {
  const observers = [];
  const sentMessages = [];
  const validTripText = [
    'رحلة الوصول',
    'تاريخ الوصول: 2026-07-08',
    'المطار: JED',
    'رقم الرحلة: SV123',
    'معلومات الفندق والخدمات'.repeat(8),
    'رحلة المغادرة',
    'تاريخ المغادرة: 2026-07-15',
  ].join('\n');
  const tripRoot = options.tripRoot || makeElement('APP-TRIP-INFO', [makeTextNode(validTripText)]);
  const serviceTagName = options.serviceTagName || 'DIV';
  const renderedText = options.renderedText || '';
  const routeChildren = options.routeChildren || [
    tripRoot,
    makeElement(serviceTagName, [
      makeTextNode([
        'الخدمات الإثرائية',
        'الخدمة نوع الخدمة تاريخ الزيارة الوقت المرشد السعر',
        'متحف السيرة النبوية والحضارية الإسلامية (برج متحف الساعة) وجهات الإثرائية 2026-07-07 08:00:00 15 ر.س',
      ].join('\n')),
    ]),
  ];
  const routeRoot = makeElement('MAIN', routeChildren, { id: 'content', innerText: renderedText });
  const body = makeElement('BODY', [routeRoot]);

  const document = {
    body,
    currentTripRoot: tripRoot,
    querySelector(selector) {
      if (selector === 'app-trip-info') return this.currentTripRoot;
      if (selector === 'main') return routeRoot;
      if (selector === '#content') return routeRoot;
      return null;
    },
    createElement(tagName) {
      return makeElement(tagName.toUpperCase());
    },
    createTextNode(value) {
      return makeTextNode(value);
    },
    createTreeWalker(root, _whatToShow, filter) {
      const nodes = [];
      function visit(node) {
        if (filter && filter.acceptNode(node) === 2) return;
        nodes.push(node);
        if (node.children) node.children.forEach(visit);
      }
      visit(root);
      let index = 0;
      return {
        nextNode() {
          return nodes[index++] || null;
        },
      };
    },
  };

  const context = {
    window: { UmrahAutoLogic: autoLogic, addEventListener() {} },
    self: null,
    globalThis: null,
    document,
    NodeFilter: { SHOW_ELEMENT: 1, SHOW_TEXT: 4, FILTER_REJECT: 2, FILTER_ACCEPT: 1 },
    Node: { ELEMENT_NODE: 1, TEXT_NODE: 3 },
    MutationObserver: class {
      constructor(callback) {
        this.callback = callback;
        observers.push(this);
      }
      observe() {}
      disconnect() {}
    },
    clearTimeout() {},
    setTimeout() {
      return 1;
    },
    chrome: {
      storage: {
        local: {
          get(keys, callback) {
            const data = { umrah_auto_enabled: true };
            if (typeof callback === 'function') callback(data);
            return Promise.resolve(data);
          },
          set() {
            return Promise.resolve();
          },
          remove() {
            return Promise.resolve();
          },
        },
        onChanged: { addListener() {} },
      },
      runtime: {
        sendMessage(message) {
          sentMessages.push(message);
          return Promise.resolve({ result: 'sent', rows: 1 });
        },
      },
    },
  };
  context.self = context.window;
  context.globalThis = context.window;

  vm.runInNewContext(autoCaptureSource, context, { filename: autoCapturePath });

  return {
    document,
    observers,
    sentMessages,
    async leaveTripPage() {
      document.currentTripRoot = null;
      observers.forEach((observer) => observer.callback([]));
      await new Promise((resolve) => setImmediate(resolve));
    },
    async detachAndLeaveTripPage() {
      routeRoot.children = routeRoot.children.filter(child => child !== tripRoot);
      document.currentTripRoot = null;
      observers.forEach((observer) => observer.callback([]));
      await new Promise((resolve) => setImmediate(resolve));
    },
  };
}

test('auto capture sends current trip text when leaving before debounce snapshot fires', async () => {
  const harness = makeHarness();

  await harness.leaveTripPage();

  assert.strictEqual(harness.sentMessages.length, 1);
  assert.strictEqual(harness.sentMessages[0].type, 'UMRAH_AUTO_FINALIZE');
  assert.match(harness.sentMessages[0].text, /رحلة الوصول/);
  assert.match(harness.sentMessages[0].text, /رحلة المغادرة/);
});

test('auto capture includes enrichment services rendered outside app-trip-info', async () => {
  const harness = makeHarness();

  await harness.leaveTripPage();

  assert.strictEqual(harness.sentMessages.length, 1);
  assert.match(harness.sentMessages[0].text, /الخدمات الإثرائية/);
  assert.match(harness.sentMessages[0].text, /متحف السيرة النبوية والحضارية الإسلامية/);
});

test('auto capture keeps enrichment services when app-trip-info is detached before finalize', async () => {
  const harness = makeHarness();

  await harness.detachAndLeaveTripPage();

  assert.strictEqual(harness.sentMessages.length, 1);
  assert.match(harness.sentMessages[0].text, /الخدمات الإثرائية/);
  assert.match(harness.sentMessages[0].text, /متحف السيرة النبوية والحضارية الإسلامية/);
});

test('auto capture includes enrichment services rendered inside clickable controls', async () => {
  const harness = makeHarness({ serviceTagName: 'BUTTON' });

  await harness.leaveTripPage();

  assert.strictEqual(harness.sentMessages.length, 1);
  assert.match(harness.sentMessages[0].text, /الخدمات الإثرائية/);
  assert.match(harness.sentMessages[0].text, /متحف السيرة النبوية والحضارية الإسلامية/);
});

test('auto capture prefers rendered page text when available', async () => {
  const harness = makeHarness({
    serviceTagName: 'SCRIPT',
    renderedText: [
      'رحلة الوصول',
      'تاريخ الوصول',
      '2026-07-08',
      'الخدمات الإثرائية',
      'الخدمة\tنوع الخدمة\tتاريخ الزيارة\tالوقت\tالمرشد\tالسعر',
      'متحف السيرة النبوية والحضارية الإسلامية (برج متحف الساعة)\tوجهات الإثرائية\t2026-07-07\t08:00:00\t\t15 ر.س',
      'رحلة المغادرة',
      'تاريخ المغادرة',
      '2026-07-15',
    ].join('\n'),
  });

  await harness.leaveTripPage();

  assert.strictEqual(harness.sentMessages.length, 1);
  assert.match(harness.sentMessages[0].text, /الخدمات الإثرائية/);
  assert.match(harness.sentMessages[0].text, /متحف السيرة النبوية والحضارية الإسلامية/);
});

test('auto capture serializes DOM structure instead of flattened rendered text', async () => {
  const tripRoot = makeElement('APP-TRIP-INFO', [
    makeElement('DIV', [makeTextNode('رحلة الوصول')]),
    makeElement('DIV', [makeTextNode('تاريخ الوصول')]),
    makeElement('DIV', [makeTextNode('2026-07-03')]),
    makeElement('DIV', [makeTextNode('المطار')]),
    makeElement('DIV', [makeTextNode('مطار الامير محمد')]),
    makeElement('DIV', [makeTextNode('الخطوط الجوية')]),
    makeElement('DIV', [makeTextNode('الخطوط اندونيسية')]),
    makeElement('DIV', [makeTextNode('الصالة')]),
    makeElement('DIV', [makeTextNode('T1')]),
    makeElement('DIV', [makeTextNode('وقت الوصول')]),
    makeElement('DIV', [makeTextNode('20:00')]),
    makeElement('DIV', [makeTextNode('رقم الرحلة')]),
    makeElement('DIV', [makeTextNode('GA-980')]),
    makeElement('DIV', [makeTextNode('الوجهة (المدينة المنورة)')]),
    makeElement('DIV', [makeTextNode('(2026-07-03 - 2026-07-06)')]),
    makeElement('DIV', [makeTextNode('الفنادق')]),
    makeElement('TABLE', [
      makeElement('TR', [
        makeElement('TH', [makeTextNode('اسم الفندق/ المستضيف')]),
        makeElement('TH', [makeTextNode('تاريخ الدخول')]),
        makeElement('TH', [makeTextNode('تاريخ المغادرة')]),
      ]),
      makeElement('TR', [
        makeElement('TD', [makeTextNode('فندق المدينة هيلتون')]),
        makeElement('TD', [makeTextNode('2026-07-03')]),
        makeElement('TD', [makeTextNode('2026-07-06')]),
      ]),
    ]),
    makeElement('DIV', [makeTextNode('الخدمات الإثرائية')]),
    makeElement('TABLE', [
      makeElement('TR', [
        makeElement('TH', [makeTextNode('الخدمة')]),
        makeElement('TH', [makeTextNode('نوع الخدمة')]),
        makeElement('TH', [makeTextNode('تاريخ الزيارة')]),
        makeElement('TH', [makeTextNode('الوقت')]),
      ]),
      makeElement('TR', [
        makeElement('TD', [makeTextNode('متحف المخطوطات الإسلامية (مكتبة الملك عبدالله — جامعة أم القرى)')]),
        makeElement('TD', [makeTextNode('وجهات الإثرائية')]),
        makeElement('TD', [makeTextNode('2026-07-04')]),
        makeElement('TD', [makeTextNode('08:00:00')]),
      ]),
    ]),
    makeElement('DIV', [makeTextNode('رحلة المغادرة')]),
    makeElement('DIV', [makeTextNode('تاريخ المغادرة')]),
    makeElement('DIV', [makeTextNode('2026-07-11')]),
  ]);

  const harness = makeHarness({
    tripRoot,
    routeChildren: [tripRoot],
    renderedText: [
      'رحلة الوصول',
      'تاريخ الوصول 2026-07-03',
      'المطار مطار الامير محمد الخطوط الجوية الخطوط اندونيسية الصالة T1 وقت الوصول 20:00',
      'رقم الرحلة GA-980',
      'الوجهة (المدينة المنورة)',
      'الفنادق اسم الفندق/ المستضيف تاريخ الدخول تاريخ المغادرة فندق المدينة هيلتون 2026-07-03 2026-07-06',
      'الخدمات الإثرائية الخدمة نوع الخدمة تاريخ الزيارة الوقت المرشد السعر متحف المخطوطات الإسلامية (مكتبة الملك عبدالله — جامعة أم القرى)وجهات الإثرائية 2026-07-04 08:00:00',
      'رحلة المغادرة',
      'تاريخ المغادرة 2026-07-11',
    ].join('\n'),
  });

  await harness.leaveTripPage();

  assert.strictEqual(harness.sentMessages.length, 1);
  assert.doesNotMatch(harness.sentMessages[0].text, /مطار الامير محمد الخطوط الجوية/);
  assert.doesNotMatch(harness.sentMessages[0].text, /أم القرى\)وجهات الإثرائية/);
  assert.match(harness.sentMessages[0].text, /المطار\nمطار الامير محمد/);
  assert.match(harness.sentMessages[0].text, /فندق المدينة هيلتون\n2026-07-03/);
  assert.match(harness.sentMessages[0].text, /أم القرى\)\nوجهات الإثرائية/);
});
